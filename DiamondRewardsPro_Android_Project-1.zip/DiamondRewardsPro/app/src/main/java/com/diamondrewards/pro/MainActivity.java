package com.diamondrewards.pro;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(12, 16, 35);
    private static final int PANEL = Color.rgb(26, 33, 63);
    private static final int GOLD = Color.rgb(255, 199, 75);
    private static final int WHITE = Color.WHITE;
    private SharedPreferences prefs;
    private LinearLayout content;
    private TextView coinText, statusText;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("diamond_demo", MODE_PRIVATE);
        showHome();
    }

    private int coins() { return prefs.getInt("coins", 250); }
    private void addCoins(int amount) {
        prefs.edit().putInt("coins", coins() + amount).apply();
        updateCoins();
    }
    private boolean spendCoins(int amount) {
        if (coins() < amount) {
            Toast.makeText(this, "Not enough demo coins!", Toast.LENGTH_SHORT).show();
            return false;
        }
        prefs.edit().putInt("coins", coins() - amount).apply();
        updateCoins();
        return true;
    }
    private void updateCoins() {
        if (coinText != null) coinText.setText("💎  " + coins() + " DEMO COINS");
    }
    private String today() { return new SimpleDateFormat("yyyyMMdd", Locale.US).format(new Date()); }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color); d.setCornerRadius(radius);
        return d;
    }
    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(4, 5, 4, 5);
        return t;
    }
    private LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }
    private void gap(LinearLayout parent, int h) {
        View v = new View(this); parent.addView(v, new LinearLayout.LayoutParams(1, h));
    }
    private Button button(String label, Runnable action) {
        Button b = new Button(this);
        b.setText(label); b.setAllCaps(false); b.setTextSize(15);
        b.setTextColor(Color.rgb(20, 25, 45));
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setBackground(shape(GOLD, 24));
        b.setPadding(12, 8, 12, 8);
        b.setOnClickListener(v -> action.run());
        return b;
    }
    private void card(LinearLayout parent, String title, String desc, String actionLabel, Runnable action) {
        LinearLayout box = vertical();
        box.setPadding(16, 12, 16, 14);
        box.setBackground(shape(PANEL, 22));
        box.addView(text(title, 18, WHITE, true));
        box.addView(text(desc, 14, Color.rgb(194, 202, 226), false));
        gap(box, 7);
        box.addView(button(actionLabel, action));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = 12;
        parent.addView(box, lp);
    }
    private void base(String pageTitle) {
        LinearLayout outer = vertical();
        outer.setBackgroundColor(BG);
        outer.setPadding(18, 16, 18, 14);

        TextView brand = text("💎 DIAMOND REWARDS PRO", 17, GOLD, true);
        outer.addView(brand);
        outer.addView(text(pageTitle, 25, WHITE, true));
        coinText = text("💎  " + coins() + " DEMO COINS", 17, GOLD, true);
        coinText.setPadding(14, 12, 14, 12);
        coinText.setBackground(shape(PANEL, 18));
        outer.addView(coinText);
        gap(outer, 12);

        ScrollView scroll = new ScrollView(this);
        content = vertical();
        scroll.addView(content);
        outer.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        LinearLayout nav = new LinearLayout(this);
        nav.setGravity(Gravity.CENTER);
        nav.setPadding(0, 10, 0, 0);
        nav.addView(button("Home", this::showHome), new LinearLayout.LayoutParams(0, -2, 1));
        nav.addView(button("Games", this::showGames), new LinearLayout.LayoutParams(0, -2, 1));
        nav.addView(button("Wallet", this::showWallet), new LinearLayout.LayoutParams(0, -2, 1));
        nav.addView(button("Profile", this::showProfile), new LinearLayout.LayoutParams(0, -2, 1));
        outer.addView(nav);
        setContentView(outer);
    }

    private void showHome() {
        base("Welcome back!");
        content.addView(text("Play • Collect • Enjoy", 19, WHITE, true));
        content.addView(text("This is a safe demo app. Coins have no cash value.", 14, Color.LTGRAY, false));
        gap(content, 12);
        card(content, "🎁 Daily Check-in", "Collect 25 demo coins once per day.", "CLAIM DAILY BONUS", () -> {
            if (today().equals(prefs.getString("last_daily", ""))) {
                Toast.makeText(this, "Daily bonus already claimed today.", Toast.LENGTH_SHORT).show();
            } else {
                prefs.edit().putString("last_daily", today()).apply();
                addCoins(25);
                Toast.makeText(this, "+25 demo coins added!", Toast.LENGTH_SHORT).show();
            }
        });
        card(content, "🎮 Play Mini Games", "Play a quick tap game or number quiz.", "OPEN GAMES", this::showGames);
        card(content, "🎯 Daily Mission", "Play one game to complete today's demo mission.", "VIEW MISSION", this::showMissions);
        card(content, "🎁 Demo Redeem", "Try the redemption flow. Nothing is delivered or paid.", "OPEN REDEEM", this::showRedeem);
    }

    private void showGames() {
        base("Mini Games");
        content.addView(text("Play games to earn demo coins only.", 14, Color.LTGRAY, false));
        card(content, "⚡ Quick Tap", "Tap the button and earn 10 demo coins per round.", "PLAY +10 COINS", () -> {
            addCoins(10);
            Toast.makeText(this, "Nice! +10 demo coins.", Toast.LENGTH_SHORT).show();
        });
        card(content, "🧠 Number Challenge", "A tiny quiz: what is 7 × 6?", "ANSWER: 42 (+15)", () -> {
            addCoins(15);
            Toast.makeText(this, "Correct! +15 demo coins.", Toast.LENGTH_SHORT).show();
        });
        card(content, "🎯 Lucky Pick", "A simple random demo bonus. No purchase or stake.", "TRY FREE (+5)", () -> {
            addCoins(5);
            Toast.makeText(this, "+5 demo coins!", Toast.LENGTH_SHORT).show();
        });
        card(content, "Daily Mission", "Complete one mini game to collect a mission bonus.", "OPEN MISSION", this::showMissions);
    }

    private void showMissions() {
        base("Daily Missions");
        content.addView(text("Mission: play any mini game and claim a 20-coin bonus.", 15, WHITE, false));
        card(content, "🏅 Play & Collect", "This demo mission can be claimed once per day.", "CLAIM MISSION (+20)", () -> {
            if (today().equals(prefs.getString("last_mission", ""))) {
                Toast.makeText(this, "Mission bonus already claimed today.", Toast.LENGTH_SHORT).show();
            } else {
                prefs.edit().putString("last_mission", today()).apply();
                addCoins(20);
                Toast.makeText(this, "Mission completed! +20 demo coins.", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showWallet() {
        base("My Wallet");
        content.addView(text("Your demo balance", 16, Color.LTGRAY, false));
        content.addView(text("💎 " + coins() + " DEMO COINS", 30, GOLD, true));
        gap(content, 8);
        card(content, "Demo transaction history", "This starter version stores your demo coin balance on this device.", "VIEW REDEEM OPTIONS", this::showRedeem);
        card(content, "Reset demo wallet", "Reset your local balance to 250 demo coins.", "RESET WALLET", () -> new AlertDialog.Builder(this)
            .setTitle("Reset demo wallet?")
            .setMessage("Your demo balance will return to 250 coins.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Reset", (d, w) -> {
                prefs.edit().putInt("coins", 250).apply();
                updateCoins();
                showWallet();
            }).show());
    }

    private void showRedeem() {
        base("Demo Redeem");
        content.addView(text("⚠ DEMO ONLY — no real rewards, gift cards, diamonds, cash, or redeem codes are issued.", 15, GOLD, true));
        gap(content, 8);
        card(content, "100 demo coins", "Preview a redemption request. No real-world value.", "TRY DEMO REDEEM", () -> {
            if (spendCoins(100)) {
                new AlertDialog.Builder(this)
                    .setTitle("Demo request successful")
                    .setMessage("This is only a simulation. No redeem code or reward has been sent. Your demo wallet was updated.")
                    .setPositiveButton("OK", null).show();
            }
        });
        card(content, "500 demo coins", "Preview a larger redemption request.", "TRY DEMO REDEEM", () -> {
            if (spendCoins(500)) {
                new AlertDialog.Builder(this).setTitle("Demo request successful")
                    .setMessage("Simulation only. No real reward is issued.")
                    .setPositiveButton("OK", null).show();
            }
        });
    }

    private void showProfile() {
        base("My Profile");
        content.addView(text("👤 Demo Player", 22, WHITE, true));
        content.addView(text("Account type: Local demo profile", 14, Color.LTGRAY, false));
        content.addView(text("Coins: " + coins(), 17, GOLD, true));
        gap(content, 10);
        card(content, "About this app", "Diamond Rewards Pro is a sample project for learning Android app development. It does not connect to a rewards provider.", "OK", () -> Toast.makeText(this, "Thanks for trying the demo!", Toast.LENGTH_SHORT).show());
        card(content, "Clear local demo data", "This removes saved demo coins and daily-claim status.", "CLEAR DATA", () -> new AlertDialog.Builder(this)
            .setTitle("Clear demo data?")
            .setMessage("Your local demo progress will be erased.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Clear", (d, w) -> {
                prefs.edit().clear().apply();
                showProfile();
            }).show());
    }
}
