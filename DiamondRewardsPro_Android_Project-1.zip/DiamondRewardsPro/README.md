# Diamond Rewards Pro Demo — Android project

## Features
- Native Android Java app (no third-party libraries)
- Local demo coin wallet using SharedPreferences
- Daily check-in and daily mission
- Three simple demo game actions
- Simulated redeem flow (no real rewards or codes)
- Home, Games, Wallet, Redeem and Profile screens

## Important
This is a demo/learning project. Coins have no monetary value. The redeem screen only simulates a request; it does not issue Free Fire diamonds, redeem codes, cash, gift cards or any real reward. No login, server, ads or payment integration is included.

## Build an APK
1. Install Android Studio on a computer.
2. Open the `DiamondRewardsPro` folder in Android Studio.
3. Let Gradle sync finish. If asked, install Android SDK Platform 35 and use JDK 17.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. The debug APK is usually created at `app/build/outputs/apk/debug/app-debug.apk`.

The project uses Android Gradle Plugin 8.6.1 and compile SDK 35. Internet is needed the first time Gradle downloads its build tools.
